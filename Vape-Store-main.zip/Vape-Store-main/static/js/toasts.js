document.addEventListener("DOMContentLoaded", function () {

    $('.toast').toast('show');

});